function TooltipFollowsYou(){
    const Icon = document.getElementById("FollowsYouIcon")
    if (Icon) $(Icon).tooltip()
}
TooltipFollowsYou()
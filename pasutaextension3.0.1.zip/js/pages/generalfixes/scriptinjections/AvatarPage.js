document.addEventListener("RedrawThumbnail", function(){
    angular.element(document.getElementById("UserAvatar")).scope().redrawThumbnail()
})
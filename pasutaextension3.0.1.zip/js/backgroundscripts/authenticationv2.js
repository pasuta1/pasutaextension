let LastAuthKeyAttempt = 0
let LastAuthenticatedUserId
let FirstAuthenticationAttempt = true

let FetchedAuthenticationFromStorage = false
let AuthenticationFailuresCounter = 0

async function HasGameFavourited(UniverseId){
    const [Success, Result] = await RequestFunc(`https://games.roblox.com/v1/games/${UniverseId}/favorites`, "GET", undefined, undefined, true)

    if (!Success){
        return [false, false]
    }

    return [true, Result.isFavorited]
}

function AlertTabsOfNewAuthKey(NewAuthKey){
    for (let i = 0; i < ActiveRobloxPages.length; i++){
        chrome.tabs.sendMessage(ActiveRobloxPages[i], {type: "Reauthenticating", AuthKey: NewAuthKey})
    }
}

async function ReauthenticateV2(){
    const UserId = await GetCurrentUserId()
    if (!UserId) return CachedAuthKey

    const [Success, Result] = await RequestFunc(WebServerEndpoints.AuthenticationV2+"reverify", "POST")

    if (Success){
        CachedAuthKey = Result.Key
        AlertTabsOfNewAuthKey(CachedAuthKey)
        LocalStorage.set("AuthKey", JSON.stringify({UserId: UserId, Key: CachedAuthKey}))
    }
    
    return CachedAuthKey
}

async function GetAuthKey(){
    let FetchedKey = ""

    if (!await IsFeatureKilled("OAuthVerification")) FetchedKey = await GetOAuthKey()
    if (FetchedKey == "") FetchedKey = await GetAuthKeyV2()
    if (FetchedKey == "") AuthenticationFailuresCounter++
    else AuthenticationFailuresCounter = 0

    if (AuthenticationFailuresCounter > 5){
        for (let i = 0; i < ActiveRobloxPages.length; i++){
            chrome.tabs.sendMessage(ActiveRobloxPages[i], {type: "AuthenticationFailure", Failed: true})
        }
    }
    
    return FetchedKey
}

async function WaitForGameFavourite(UserId, UniverseId, Favourited = true, Timeout = 15){
    const End = (Date.now()/1000)+Timeout

    while (End > Date.now()/1000){
        if (await GetCurrentUserId() !== UserId) return false

        const [Success, Result] = await RequestFunc(`https://www.roblox.com/users/favorites/list-json?assetTypeId=9&itemsPerPage=1&pageNumber=1&userId=${UserId}`, "GET", undefined, undefined, true)
        
        if (Success){
            const FavouritedUniverseId = Result?.Data?.Items?.[0]?.Item?.UniverseId

            if (Favourited && UniverseId == FavouritedUniverseId) return true
            if (!Favourited && UniverseId != FavouritedUniverseId) return true
        }
        await sleep(2000)
    }

    return false
}

async function GetAuthKeyV2(){
    if ((Date.now()/1000) - LastAuthKeyAttempt < 3){
        await sleep(3000)
    }

    while (FetchingAuthKey){
        await sleep(100)
    }

    FetchingAuthKey = true
    
    const UserId = await GetCurrentUserId()
    if (!UserId){
        FetchingAuthKey = false
        return "" //No userid, so we cannot validate
    }

    async function CheckIfSameUser(ResetAuthKey = true){
        if (UserId !== await GetCurrentUserId()){
            if (ResetAuthKey) FetchingAuthKey = false
            return false
        }
        return true
    }

    if (CachedAuthKey != "" && UserId == LastAuthenticatedUserId){
        FetchingAuthKey = false
        return CachedAuthKey
    }
    if (UserId != LastAuthenticatedUserId && !FirstAuthenticationAttempt){
        CachedAuthKey = ""
        FetchingAuthKey = true
        AlertTabsOfNewAuthKey()
        await LocalStorage.remove("AuthKey")
    }

    FirstAuthenticationAttempt = false
    FetchingAuthKey = true
    LastAuthKeyAttempt = Date.now()/1000

    StoredKey = await LocalStorage.get("AuthKey")
    if (StoredKey){
        try {
            StoredKey = JSON.parse(StoredKey)
        } catch {}
    }
    
    if (StoredKey){
        if (typeof(StoredKey) == "string"){
            StoredKey = {UserId: UserId, Key: StoredKey}
            await LocalStorage.set("AuthKey", JSON.stringify(StoredKey))
        }

        if (StoredKey.UserId == UserId){
            FetchedAuthenticationFromStorage = true

            CachedAuthKey = StoredKey.Key
            LastAuthenticatedUserId = UserId
            FetchingAuthKey = false
            return CachedAuthKey
        }
    }

    FetchedAuthenticationFromStorage = false
    
    if (!await CheckIfSameUser()){
        FetchingAuthKey = false
        return ""
    }

    LastAuthenticatedUserId = UserId
    const [GetFavoriteSuccess, FavoriteResult] = await RequestFunc(WebServerEndpoints.AuthenticationV2+"fetch", "POST", undefined, JSON.stringify({UserId: UserId}))
    
    if (!GetFavoriteSuccess || !await CheckIfSameUser()){
        FetchingAuthKey = false
        return ""
    }
    
    Key = FavoriteResult.Key
    UniverseId = FavoriteResult.UniverseId

    ForceMustUnfavourite = false
    if (!FavoriteResult.MustUnfavourite){
        [Success, Favourited] = await HasGameFavourited(UniverseId)

        if (!Success){
            FetchingAuthKey = false
            return ""
        }

        ForceMustUnfavourite = Favourited
    }
    if (!await CheckIfSameUser()) return

    if (FavoriteResult.MustUnfavourite || ForceMustUnfavourite){
        const [FavouriteSuccess] = await SetFavouriteGame(UniverseId, false)
    
        if (!FavouriteSuccess){
            FetchingAuthKey = false
            return ""
        }

        if (FavoriteResult.MustUnfavourite){
            await WaitForGameFavourite(UserId, UniverseId, false, 15)
            const [UnfavoriteSuccess] = await RequestFunc(WebServerEndpoints.AuthenticationV2+"clear", "POST", undefined, JSON.stringify({Key: Key}))

            if (!UnfavoriteSuccess){
                FetchingAuthKey = false
                return ""
            }
        }
    }
    
    const [FavouriteSuccess] = await SetFavouriteGame(UniverseId, true)
    
    if (!FavouriteSuccess || !await CheckIfSameUser()){
        FetchingAuthKey = false
        return ""
    }
    
    await WaitForGameFavourite(UserId, UniverseId, true, 15)
    if (!await CheckIfSameUser()) return

    const [ServerSuccess, ServerResult] = await RequestFunc(WebServerEndpoints.AuthenticationV2+"verify", "POST", undefined, JSON.stringify({Key: Key}))
    if (!await CheckIfSameUser()) return

    if (ServerSuccess){
        CachedAuthKey = ServerResult.Key
        LocalStorage.set("AuthKey", JSON.stringify({UserId: UserId, Key: CachedAuthKey}))
        AlertTabsOfNewAuthKey(CachedAuthKey)
    }
    
    new Promise(async function(){
        let UnfavouriteAttempts = 0

        while (true){
            if (!await CheckIfSameUser(false)) return

            const [FavSuccess] = await SetFavouriteGame(UniverseId, false)
    
            if (FavSuccess) break
            UnfavouriteAttempts++
            if (UnfavouriteAttempts > 10) UnfavouriteAttempts = 10

            await sleep(1000 * (10+UnfavouriteAttempts))
        }
    })
    
    FetchingAuthKey = false
    AuthenticationFailuresCounter = 0
    
    return CachedAuthKey
}

async function GetAuthKeyDetailed(){
    const AuthKey = await GetAuthKey()
    return [AuthKey != "" ? AuthKey : null, AuthKey != "" ? LastAuthenticatedUserId : null]
}

function IsOver13(y, m, d){
    const r = new Date()

    if(r.getFullYear() <= (parseInt(y) + 13)){ 
        if((r.getMonth()+1) <= m){
             if(r.getDate() < d){
                 return false
 }}}

 return true
}

async function GetOAuthKey(){
    if ((Date.now()/1000) - LastAuthKeyAttempt < 3){
        await sleep(3000)
    }

    while (FetchingAuthKey){
        await sleep(100)
    }

    FetchingAuthKey = true
    
    const UserId = await GetCurrentUserId()
    if (!UserId){
        FetchingAuthKey = false
        return "" //No userid, so we cannot validate
    }

    async function CheckIfSameUser(ResetAuthKey = true){
        if (UserId !== await GetCurrentUserId()){
            if (ResetAuthKey) FetchingAuthKey = false
            return false
        }
        return true
    }

    if (CachedAuthKey != "" && UserId == LastAuthenticatedUserId){
        FetchingAuthKey = false
        return CachedAuthKey
    }
    if (UserId != LastAuthenticatedUserId && !FirstAuthenticationAttempt){
        CachedAuthKey = ""
        FetchingAuthKey = true
        AlertTabsOfNewAuthKey()
        await LocalStorage.remove("AuthKey")
    }

    FirstAuthenticationAttempt = false
    FetchingAuthKey = true
    LastAuthKeyAttempt = Date.now()/1000

    StoredKey = await LocalStorage.get("AuthKey")
    if (StoredKey){
        try {
            StoredKey = JSON.parse(StoredKey)
        } catch {}
    }
    
    if (StoredKey){
        if (typeof(StoredKey) == "string"){
            StoredKey = {UserId: UserId, Key: StoredKey}
            await LocalStorage.set("AuthKey", JSON.stringify(StoredKey))
        }

        if (StoredKey.UserId == UserId){
            FetchedAuthenticationFromStorage = true

            CachedAuthKey = StoredKey.Key
            LastAuthenticatedUserId = UserId
            FetchingAuthKey = false
            return CachedAuthKey
        }
    }

    FetchedAuthenticationFromStorage = false
    
    if (!await CheckIfSameUser()){
        FetchingAuthKey = false
        return ""
    }

    LastAuthenticatedUserId = UserId

    let [Success, Result, Response] = await RequestFunc("https://accountinformation.roblox.com/v1/birthdate", "GET", undefined, undefined, true)
    if (!Success){
        FetchingAuthKey = false
        return ""
    }

    if (!IsOver13(Result.birthYear, Result.birthMonth, Result.birthDay)){
        FetchingAuthKey = false
        return ""
    }

    ;[Success, _, Response] = await RequestFunc(WebServerEndpoints.OAuth, "GET", undefined, undefined, true, true)
    if (!Success){
        FetchingAuthKey = false
        return ""
    }

    if (!await CheckIfSameUser()){
        FetchingAuthKey = false
        return ""
    }

    const Params = new URLSearchParams(Response.url.split("?")[1])
    const Scopes = []

    const UnparsedScopes = Params.get("scope").split(" ")
    for (let i = 0; i < UnparsedScopes.length; i++){
        Scopes[i] = {scopeType: UnparsedScopes[i], operations: ["read"]}
    }

    function Capitalize(string){
        return string.charAt(0).toUpperCase() + string.slice(1)
    }

    const AuthorizationBody = {
        clientId: Params.get("client_id"),
        codeChallenge: Params.get("code_challenge"),
        codeChallengeMethod: Params.get("code_challenge_method"),
        nonce: Params.get("nonce"),
        redirectUri: Params.get("redirect_uri"),
        resourceInfos: [{owner: {id: UserId.toString(), type: "User"}, resources: {}}],
        responseTypes: [Capitalize(Params.get("response_type"))],
        scopes: Scopes,
        state: Params.get("state")
    }

    ;[Success, Result] = await RequestFunc("https://apis.roblox.com/oauth/v1/authorizations", "POST", {"Content-Type": "application/json"}, JSON.stringify(AuthorizationBody), true, false)
    if (!Success){
        FetchingAuthKey = false
        return ""
    }

    if (!Result?.location){
        FetchingAuthKey = false
        return ""
    }
    ;[Success, _, Response] = await RequestFunc(Result.location, "GET", {type: "Authentication"}, undefined, false, true)
    if (!Success){
        FetchingAuthKey = false
        return ""
    }

    CachedAuthKey = (await Response.json()).Key
    LocalStorage.set("AuthKey", JSON.stringify({UserId: UserId, Key: CachedAuthKey}))
    AlertTabsOfNewAuthKey(CachedAuthKey)

    FetchingAuthKey = false
    AuthenticationFailuresCounter = 0

    return CachedAuthKey
}

// async function CanOAuthVerify(UserId){
//     if (!UserId) return false

//     const Keys = await LocalStorage.get("OAuth")
// }

// async function GetAuthKeyOAuth(UserId){
//     if (!UserId) return ""
//     if ((Date.now()/1000) - LastAuthKeyAttempt < 3){
//         await sleep(3000)
//     }

//     while (FetchingAuthKey){
//         await sleep(100)
//     }

//     FetchingAuthKey = true
// }